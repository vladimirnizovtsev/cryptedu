from django.apps import AppConfig


class LimitOrderConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "limit_order"
